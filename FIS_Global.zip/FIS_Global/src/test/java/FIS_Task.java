import java.time.Duration;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
 
public class FIS_Task {
	
	public WebDriver driver;

	@BeforeMethod
	public void setUp() {

		driver = new ChromeDriver();
		driver.manage().window().maximize();

	}

	@Test
	public void addItemToCart() throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		driver.get("https://www.ebay.com");

		WebElement serachbook = wait
				.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='gh-ac']")));

		serachbook.sendKeys("book");

		driver.findElement(By.xpath("//input[@id='gh-btn']")).click();

		WebElement serachresult1 = wait.until(
				ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='srp-river-main']/following::img[1]")));

		serachresult1.click();

		Set<String> windowHandles = driver.getWindowHandles();
		String originalWindow = driver.getWindowHandle();

		for (String handle : windowHandles) {
			if (!handle.equals(originalWindow)) {
				driver.switchTo().window(handle);
				break;
			}
		}

		WebElement firstDropdown = wait.until(ExpectedConditions.visibilityOfElementLocated(By
				.xpath("//div[@id='mainContent']/following::span[@class='btn__text'][normalize-space()='Select'][1]")));
		Select firstDropdownSelect = new Select(firstDropdown);
		firstDropdownSelect.selectByIndex(0);

		WebElement secondDropdown = wait.until(ExpectedConditions.visibilityOfElementLocated(By
				.xpath("//div[@id='mainContent']/following::span[@class='btn__text'][normalize-space()='Select'][2]")));
		Select secondDropdownSelect = new Select(secondDropdown);
		secondDropdownSelect.selectByIndex(0);

		driver.findElement(By.xpath("//span[text()='Add to cart")).click();

		WebElement cartIcon = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("gh-cart-n")));
		String cartItemCount = cartIcon.getText();

		System.out.println(" number of item added in cart is " + cartItemCount);

	}

	@AfterMethod
	public void tearDown() {

		driver.quit();
	}

}
