import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import io.restassured.RestAssured;
import io.restassured.response.Response;
 
public class APITask {
	
 

	@Test
	public void addItemToCart() throws InterruptedException {
		
		Response response = RestAssured.given().baseUri("https://api.coindesk.com")
				.basePath("/v1/bpi/currentprice.json").get();
		Assert.assertEquals(response.getStatusCode(), 200, "Status Code is not 200");
		
		Map<String, Object> responseJson = response.jsonPath().getMap("$");
		Map<String, Map<String, Object>> bpi = (Map<String, Map<String, Object>>) responseJson.get("bpi");

		List<String> expectedCurrencies = List.of("USD", "GBP", "EUR");
		for (String currency : expectedCurrencies) {
			Assert.assertTrue(bpi.containsKey(currency), "Currency " + currency + " is missing");
		}

		String gbpDescription = (String) bpi.get("GBP").get("description");
		
		System.out.println("gbpDescription "+gbpDescription);
		Assert.assertEquals(gbpDescription, "British Pound Sterling", "GBP description is not as expected");

		
		System.out.println("Response: " + response.getBody().asString());
	 
	}

	 
}
